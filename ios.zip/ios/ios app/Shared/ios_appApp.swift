//
//  ios_appApp.swift
//  Shared
//
//  Created by Abhishek Anand on 24/06/23.
//

import SwiftUI

@main
struct ios_appApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
