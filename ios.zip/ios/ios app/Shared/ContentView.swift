import SwiftUI

struct ContentView: View {
    @State private var showSheet: Bool = false
    @State private var showImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var image: UIImage?

    
    var body: some View {
        
        NavigationView {
            GeometryReader { geometry in
            
            VStack {
                Spacer()
                
                Text("Brain Stroke")
                                        .font(.title)
                                        .frame(width: geometry.size.width, height: 100)
                 Spacer()
                
                Image(uiImage: image ?? UIImage(named: "brain.jpeg")!)
                       .resizable()
                       .frame(width: 200, height: 200)
                Spacer()
                
                Button("Choose Option") {
                    
                    self.showSheet = true
                }
                .padding()
                .actionSheet(isPresented: $showSheet) {
                    ActionSheet(title: Text("Choose Option"), message: Text("Select"), buttons: [
                                    .default(Text("Gallery")) {
                                        self.showImagePicker = true
                                        self.sourceType = .photoLibrary
                    
                                        
                                    },
                                    .default(Text("Camera")) {
                                        self.showImagePicker = true
                                        self.sourceType = .camera
                                    },
                                    .cancel()
                                ])
            
                }
                
                Spacer()
                
            }
                                    
                                    
                                    
            }
            
        .navigationBarTitle("Brain Stroke")
        .navigationBarHidden(true)
        
            
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(image: self.$image,  isShown: self.$showImagePicker, sourceType: self.sourceType)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

